<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Transaksi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4"><i class="bi bi-receipt"></i> Daftar Transaksi Peminjaman</h1>
        
        <?php
        // Hitung statistik dengan loop
        $total_transaksi = 0;
        $total_dipinjam = 0;
        $total_dikembalikan = 0;
        
        // Loop pertama untuk hitung statistik
        for ($i = 1; $i <= 10; $i++) {
            // Skip transaksi genap
            if ($i % 2 == 0) {
                continue;
            }

            // Stop di transaksi ke-8
            if ($i == 8) {
                break;
            }

            $status = ($i % 3 == 0) ? "Dikembalikan" : "Dipinjam";

            $total_transaksi++;

            if ($status == "Dipinjam") {
                $total_dipinjam++;
            } else {
                $total_dikembalikan++;
            }
        }
        ?>
        
        <!-- Tampilkan statistik dalam cards -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card border-primary">
                    <div class="card-body text-center">
                        <h3 class="text-primary"><?php echo $total_transaksi; ?></h3>
                        <p class="mb-0"><i class="bi bi-list-ul"></i> Total Transaksi</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-warning">
                    <div class="card-body text-center">
                        <h3 class="text-warning"><?php echo $total_dipinjam; ?></h3>
                        <p class="mb-0"><i class="bi bi-book"></i> Masih Dipinjam</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-success">
                    <div class="card-body text-center">
                        <h3 class="text-success"><?php echo $total_dikembalikan; ?></h3>
                        <p class="mb-0"><i class="bi bi-check-circle"></i> Sudah Dikembalikan</p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Tampilkan tabel transaksi -->
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="bi bi-table"></i> Riwayat Transaksi</h5>
            </div>
            <div class="card-body">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>No</th>
                            <th>ID Transaksi</th>
                            <th>Peminjam</th>
                            <th>Buku</th>
                            <th>Tgl Pinjam</th>
                            <th>Tgl Kembali</th>
                            <th>Hari</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        for ($i = 1; $i <= 10; $i++) {
                            // Gunakan continue untuk skip transaksi genap
                            if ($i % 2 == 0) {
                                continue;
                            }

                            // Gunakan break untuk stop di transaksi ke-8
                            if ($i == 8) {
                                break;
                            }

                            // Generate data transaksi
                            $id_transaksi = "TRX-" . str_pad($i, 4, "0", STR_PAD_LEFT);
                            $nama_peminjam = "Anggota " . $i;
                            $judul_buku = "Buku Teknologi Vol. " . $i;
                            $tanggal_pinjam = date('Y-m-d', strtotime("-$i days"));
                            $tanggal_kembali = date('Y-m-d', strtotime("+7 days", strtotime($tanggal_pinjam)));
                            $status = ($i % 3 == 0) ? "Dikembalikan" : "Dipinjam";

                            // Hitung jumlah hari sejak pinjam
                            $hari_sejak_pinjam = $i;

                            // Warna berbeda untuk tiap status
                            if ($status == "Dikembalikan") {
                                $warna_baris = "table-success";
                                $warna_badge = "success";
                                $icon_badge = "check-circle";
                            } else {
                                $warna_baris = "table-warning";
                                $warna_badge = "warning";
                                $icon_badge = "clock";
                            }
                        ?>
                        <tr class="<?php echo $warna_baris; ?>">
                            <td><?php echo $no; ?></td>
                            <td><code><?php echo $id_transaksi; ?></code></td>
                            <td><?php echo $nama_peminjam; ?></td>
                            <td><?php echo $judul_buku; ?></td>
                            <td><?php echo $tanggal_pinjam; ?></td>
                            <td><?php echo $tanggal_kembali; ?></td>
                            <td><?php echo $hari_sejak_pinjam; ?> hari</td>
                            <td>
                                <span class="badge bg-<?php echo $warna_badge; ?> text-dark">
                                    <i class="bi bi-<?php echo $icon_badge; ?>"></i>
                                    <?php echo $status; ?>
                                </span>
                            </td>
                        </tr>
                        <?php
                            $no++;
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>