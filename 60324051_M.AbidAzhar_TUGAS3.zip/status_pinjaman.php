<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Status Peminjaman</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4"><i class="bi bi-person-badge"></i> Status Peminjaman Perpustakaan</h1>

        <?php
        // Data Anggota
        $nama_anggota = "Budi Santoso";
        $total_pinjaman = 2;
        $buku_terlambat = 1;
        $hari_keterlambatan = 5; // hari

        // Hitung denda keterlambatan
        $total_denda = $buku_terlambat * $hari_keterlambatan * 1000;

        // Maksimal denda Rp 50.000
        if ($total_denda > 50000) {
            $total_denda = 50000;
        }

        // Cek apakah anggota bisa pinjam lagi
        if ($buku_terlambat > 0) {
            $bisa_pinjam = false;
            $pesan_status = "Tidak dapat meminjam buku karena ada buku yang terlambat dikembalikan.";
            $warna_status = "danger";
            $icon_status = "x-circle";
        } elseif ($total_pinjaman >= 3) {
            $bisa_pinjam = false;
            $pesan_status = "Tidak dapat meminjam buku karena sudah mencapai batas maksimal 3 buku.";
            $warna_status = "warning";
            $icon_status = "exclamation-triangle";
        } else {
            $bisa_pinjam = true;
            $pesan_status = "Silakan pilih buku yang ingin dipinjam.";
            $warna_status = "success";
            $icon_status = "check-circle";
        }

        // Tentukan level member dengan SWITCH
        // Bronze: 0-5 | Silver: 6-15 | Gold: >15
        if ($total_pinjaman <= 5) {
            $range_member = "bronze";
        } elseif ($total_pinjaman <= 15) {
            $range_member = "silver";
        } else {
            $range_member = "gold";
        }

        switch ($range_member) {
            case "bronze":
                $level_member = "Bronze";
                $warna_member = "secondary";
                $icon_member = "award";
                break;
            case "silver":
                $level_member = "Silver";
                $warna_member = "info";
                $icon_member = "award-fill";
                break;
            case "gold":
                $level_member = "Gold";
                $warna_member = "warning";
                $icon_member = "trophy-fill";
                break;
            default:
                $level_member = "Tidak Diketahui";
                $warna_member = "secondary";
                $icon_member = "question-circle";
        }
        ?>

        <!-- Informasi Anggota -->
        <div class="card mb-3">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="bi bi-person-circle"></i> Informasi Anggota</h5>
            </div>
            <div class="card-body">
                <table class="table table-bordered mb-0">
                    <tr>
                        <th width="200">Nama Anggota</th>
                        <td><?php echo $nama_anggota; ?></td>
                    </tr>
                    <tr>
                        <th>Level Member</th>
                        <td>
                            <span class="badge bg-<?php echo $warna_member; ?>">
                                <i class="bi bi-<?php echo $icon_member; ?>"></i> <?php echo $level_member; ?>
                            </span>
                        </td>
                    </tr>
                    <tr>
                        <th>Total Pinjaman</th>
                        <td><?php echo $total_pinjaman; ?> buku</td>
                    </tr>
                    <tr>
                        <th>Buku Terlambat</th>
                        <td><?php echo $buku_terlambat; ?> buku</td>
                    </tr>
                    <tr>
                        <th>Hari Keterlambatan</th>
                        <td><?php echo $hari_keterlambatan; ?> hari</td>
                    </tr>
                </table>
            </div>
        </div>

        <!-- Status Peminjaman -->
        <div class="card mb-3">
            <div class="card-header bg-<?php echo $warna_status; ?> text-white">
                <h5 class="mb-0">
                    <i class="bi bi-<?php echo $icon_status; ?>"></i>
                    Status: <?php echo $bisa_pinjam ? "Dapat Meminjam" : "Tidak Dapat Meminjam"; ?>
                </h5>
            </div>
            <div class="card-body">
                <p class="mb-0"><?php echo $pesan_status; ?></p>
            </div>
        </div>

        <!-- Peringatan Keterlambatan -->
        <?php if ($buku_terlambat > 0) { ?>
        <div class="alert alert-warning">
            <h5><i class="bi bi-exclamation-triangle"></i> Peringatan Keterlambatan</h5>
            <p>Anda memiliki <strong><?php echo $buku_terlambat; ?> buku</strong> yang terlambat
                selama <strong><?php echo $hari_keterlambatan; ?> hari</strong>.</p>
            <p class="mb-0">
                <strong>Total Denda:</strong> Rp <?php echo number_format($total_denda, 0, ',', '.'); ?>
            </p>
        </div>
        <?php } ?>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>